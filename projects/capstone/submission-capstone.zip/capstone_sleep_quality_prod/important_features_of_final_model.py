import train_and_test
from lib.results_handler import generate_results,summurize_results,showing_mean_values
import pandas as pd
features_final, target_var= train_and_test.get_feature_final_and_target_var()

# Specifying information of the result I want.
result_keys = [
            'random_state',
            'clf_1_accuracy',
            'clf_1_n_estimators',
            'clf_2_accuracy',
            'clf_2_n_estimators',
            'important_features',
            'time'
        ]

# Specifying the argument of the method which executes training and testing except for random_state
other_args = {'features_final': features_final, 'target_var': target_var,'f_select_range':[0,50]}

#Specify random_states you wish to try
random_states = range(1)

#Executing  training and testing 10 times with 10 different inputs and getting the results
all_res_df = generate_results(train_and_test, 'train_and_measure_performance_3', result_keys, random_states, other_args)

# Making pandas dataframe to show all the rows
pd.set_option("display.max_colwidth", 1000)
pd.set_option("display.max_rows", 1000)

# Getting correlations between q30 and the other features
features_to_focus = list(all_res_df['important_features'][0].index)
features_final['q30'] = target_var
features_to_focus.append('q30')
correlations = features_final[features_to_focus].corr()

# Showing important features and
print all_res_df['important_features'][0]
print correlations['q30']

#Saving correlation between q30 and the other features
correlations['q30'].to_csv('corr_q30_of_important_features_of_final_model_f_50_r_0.csv')
all_res_df['important_features'][0].to_csv('important_features_of_final_model_f_50_r_0.csv')

