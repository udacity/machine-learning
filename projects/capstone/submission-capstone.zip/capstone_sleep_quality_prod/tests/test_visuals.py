import unittest
import sys,os
import pandas as pd
import numpy as np
sys.path.append(os.pardir)
sys.path.append('../lib')
from lib.visuals import Visuals
from assert_method_is_called import assertMethodIsCalled
from pandas.util.testing import assert_frame_equal
from unittest_data_provider import data_provider
from collections import OrderedDict


class TestVisuals(unittest.TestCase):
    def setUp(self):
        self.ins = Visuals()

    # python test_visuals.py TestVisuals.test_count_each_num_of_values_belongs_to_each_range__returns_expected_values
    __data_for_test_count_each_num_of_values_belongs_to_each_range__returns_expected_values = lambda: [
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0, 99.9, 100, 199.9, 200, 299.9, 300], index=[0, 1, 2, 3, 4, 5, 6]),
                }
            ),
            3,
            0,
            300,
            None,
            OrderedDict([
                ('0-100', 2), ('100-200', 2), ('200-300', 2),
            ])
        ],
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0, 99.9, 100, 199.9, 200, 299.9, 300], index=[0, 1, 2, 3, 4, 5, 6]),
                }
            ),
            3,
            0,
            300,
            'ordered_dict',
            OrderedDict([
                ('0-100', 2), ('100-200', 2), ('200-300', 2),
            ])
        ],
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0, 99.9, 100, 199.9, 200, 299.9, 300], index=[0, 1, 2, 3, 4, 5, 6]),
                }
            ),
            3,
            0,
            300,
            'tuples',
            ('0-100', '100-200', '200-300'),
            (2, 2, 2)
        ],
    ]

    @data_provider(__data_for_test_count_each_num_of_values_belongs_to_each_range__returns_expected_values)
    def test_count_each_num_of_values_belongs_to_each_range__returns_expected_values(self, df, num_of_classes, r_min, r_max, return_type, expected_1,expected_2=None):
        if return_type == None:
            actual = self.ins.count_each_num_of_values_belongs_to_each_range(df['one'], num_of_classes, r_min, r_max)
            self.assertEqual(expected_1, actual)
        elif return_type == 'ordered_dict':
            actual = self.ins.count_each_num_of_values_belongs_to_each_range(df['one'], num_of_classes, r_min, r_max, return_type)
            self.assertEqual(expected_1, actual)
        elif return_type == 'tuples':
            actual_1, actual_2 = self.ins.count_each_num_of_values_belongs_to_each_range(df['one'], num_of_classes, r_min, r_max, return_type)
            self.assertTupleEqual(expected_1, actual_1)
            self.assertTupleEqual(expected_2, actual_2)

    # python test_visuals.py TestVisuals.test_count_each_num_of_values_belongs_to_each_value__returns_expected_values
    __data_for_test_count_each_num_of_values_belongs_to_each_value__returns_expected_values = lambda: [
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0, 1, 2, 0, 1, 2, 0, 1, 2], index=[0, 1, 2, 3, 4, 5, 6, 7, 8]),
                }
            ),
            0,
            2,
            'ordered_dict',
            OrderedDict([
                (0, 3), (1, 3), (2, 3),
            ])
        ],
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0, 1, 2, 0, 1, 2, 0, 1, 2], index=[0, 1, 2, 3, 4, 5, 6, 7, 8]),
                }
            ),
            1,
            2,
            'ordered_dict',
            OrderedDict([
                (1, 3), (2, 3),
            ])
        ],
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0, 1, 2, 0, 1, 2, 0, 1, 2], index=[0, 1, 2, 3, 4, 5, 6, 7, 8]),
                }
            ),
            0,
            2,
            'tuples',
            (0, 1, 2),
            (3, 3, 3),
        ]
    ]

    @data_provider(__data_for_test_count_each_num_of_values_belongs_to_each_value__returns_expected_values)
    def test_count_each_num_of_values_belongs_to_each_value__returns_expected_values(self, df, r_min, r_max, return_type,
                                                                 expected_1, expected_2=None):
        if return_type == None:
            actual = self.ins.count_each_num_of_values_belongs_to_each_value(df['one'], r_min, r_max)
            self.assertEqual(expected_1, actual)
        elif return_type == 'ordered_dict':
            actual = self.ins.count_each_num_of_values_belongs_to_each_value(df['one'], r_min, r_max, return_type)
            self.assertEqual(expected_1, actual)
        elif return_type == 'tuples':
            actual_1, actual_2 = self.ins.count_each_num_of_values_belongs_to_each_value(df['one'],  r_min, r_max,return_type)
            self.assertTupleEqual(expected_1, actual_1)
            self.assertTupleEqual(expected_2, actual_2)

    # python test_visuals.py TestVisuals.test_count_each_num_of_values_belongs_to_each_class__returns_expected_values
    __data_for_test_count_each_num_of_values_belongs_to_each_class__returns_expected_values = lambda: [
        [
            pd.DataFrame(
                {
                    'one': pd.Series([100, 200, 300, 100, 200, 300, 100, 200, 300], index=[0, 1, 2, 3, 4, 5, 6, 7, 8]),
                }
            ),
            3,
            0,
            300,
            None,
            OrderedDict([
                ('0-100', 3), ('101-200', 3), ('201-300', 3),
            ])
        ],
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0, 1, 2, 0, 1, 2, 0, 1, 2], index=[0, 1, 2, 3, 4, 5, 6, 7, 8]),
                }
            ),
            3,
            0,
            2,
            None,
            OrderedDict([
                (0, 3), (1, 3), (2, 3),
            ])
        ],
    ]

    @data_provider(__data_for_test_count_each_num_of_values_belongs_to_each_class__returns_expected_values)
    def test_count_each_num_of_values_belongs_to_each_class__returns_expected_values(self, df, num_of_classes, r_min, r_max, return_type, expected_1,
                                                   expected_2=None):
        if num_of_classes == r_max + 1:
            with assertMethodIsCalled(self.ins, "count_each_num_of_values_belongs_to_each_value"):
                self.ins.count_each_num_of_values_belongs_to_each_class(df['one'], num_of_classes, r_min, r_max)
        else:
            with assertMethodIsCalled(self.ins, "count_each_num_of_values_belongs_to_each_range"):
                self.ins.count_each_num_of_values_belongs_to_each_class(df['one'], num_of_classes, r_min, r_max)



    # python test_visuals.py TestVisuals.test_get_range_lists__returns_expected_values
    __data_for_test_get_range_lists__returns_expected_values = lambda: [
        [
            10,
            40,
            3,
            [
                [10, 20],
                [20, 30],
                [30, 40],
            ],
        ],
    ]

    @data_provider(__data_for_test_get_range_lists__returns_expected_values)
    def test_get_range_lists__returns_expected_values(self,r_min, r_max,num_of_classes, expected):
        actual = self.ins.get_range_lists(r_min, r_max, num_of_classes)
        self.assertListEqual(actual,expected)


    # python test_visuals.py TestVisuals.test_get_indexes_whose_values_in_certain_ranges__returns_expected_values
    __data_for_test_get_indexes_whose_values_in_certain_ranges__returns_expected_values = lambda: [
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0,9,10,19,20,29,30], index=[0, 1, 2, 3, 4, 5, 6]),
                }
            ),
            'one',
            [
                [0, 10],
                [10, 20],
                [20, 30],
            ],
            # OrderedDict([
            #     (0, [0,9]), (1, [10,19]), (2, [20,29]),
            # ])
            [
                [0, 1],
                [2, 3],
                [4, 5]
            ]

        ],
    ]
    @data_provider(__data_for_test_get_indexes_whose_values_in_certain_ranges__returns_expected_values)
    def test_get_indexes_whose_values_in_certain_ranges__returns_expected_values(self, df, column_name, lefts_and_rights, expected):
        actual = self.ins.get_indexes_whose_values_in_certain_ranges(df, column_name, lefts_and_rights)
        self.assertListEqual(actual, expected)

    # python test_visuals.py TestVisuals.test_get_values_lists_from_specified_column_and_indexes_list__returns_expected_values
    __data_for_test_get_values_lists_from_specified_column_and_indexes_list__returns_expected_values = lambda: [
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0,9,10,19,20,29,30], index=[0, 1, 2, 3, 4, 5, 6]),
                    'two': pd.Series([4, 3, 3, 4, 1, 4, 1], index=[0, 1, 2, 3, 4, 5, 6]),
                }
            ),
            'two',
            [
                [0, 1],
                [2, 3],
                [4, 5]
            ],
            [
                [4, 3],
                [3,4],
                [1,4]
            ]
        ],
    ]
    @data_provider(__data_for_test_get_values_lists_from_specified_column_and_indexes_list__returns_expected_values)
    def test_get_values_lists_from_specified_column_and_indexes_list__returns_expected_values(self, df, column_name, lefts_and_rights, expected):
        actual = self.ins.get_values_lists_from_specified_column_and_indexes_lists(df, column_name, lefts_and_rights)
        self.assertListEqual(expected, actual)


    # python test_visuals.py TestVisuals.test_get_averages_of_values__returns_expected_values
    __data_for_test_get_averages_of_values__returns_expected_values = lambda: [
        [
            [
                [4, 3],
                [3,4],
                [1,4]
            ],
            [
                3.5,
                3.5,
                2.5
            ]

        ],
    ]
    @data_provider(__data_for_test_get_averages_of_values__returns_expected_values)
    def test_get_averages_of_values__returns_expected_values(self,values_list,expected):
        actual = self.ins.get_averages_of_values(values_list)
        self.assertListEqual(expected, actual)

    # python test_visuals.py TestVisuals.test_get_averages_of_specified_column_and_indexes_lists__returns_expected_values
    __data_for_test_get_averages_of_specified_column_and_indexes_lists__returns_expected_values = lambda: [
        [
            pd.DataFrame(
                {
                    'one': pd.Series([0,9,10,19,20,29,30], index=[0, 1, 2, 3, 4, 5, 6]),
                    'two': pd.Series([4, 3, 3, 4, 1, 4, 1], index=[0, 1, 2, 3, 4, 5, 6]),
                }
            ),
            'two',
            [
                [0, 1],
                [2, 3],
                [4, 5]
            ],
            [
                3.5,
                3.5,
                2.5
            ]
        ],
    ]
    @data_provider(__data_for_test_get_averages_of_specified_column_and_indexes_lists__returns_expected_values)
    def test_get_averages_of_specified_column_and_indexes_lists__returns_expected_values(self, df, column_name, lefts_and_rights, expected):
        actual = self.ins.get_averages_of_specified_column_and_indexes_lists(df, column_name, lefts_and_rights)
        self.assertListEqual(expected, actual)

    # python test_visuals.py TestVisuals.test_remove_lines_which_have_certain_values__returns_expected_values
    __data_for_test_remove_lines_which_have_certain_values__returns_expected_values = lambda: [
        [
            pd.DataFrame(
                {
                    'one': pd.Series([97,98,99], index=[0, 1, 2]),
                    'two': pd.Series([94,95,96], index=[0, 1, 2]),
                }
            ),
            'one',
            [98,99],
            pd.DataFrame(
                {
                    'one': pd.Series([97], index=[0]),
                    'two': pd.Series([94], index=[0]),
                }
            ),
        ],
    ]
    @data_provider(__data_for_test_remove_lines_which_have_certain_values__returns_expected_values)
    def test_remove_lines_which_have_certain_values__returns_expected_values(self, df, column_name, unnecessary_values,expected):
        actual = self.ins.remove_lines_which_have_certain_values(df, column_name, unnecessary_values)
        assert_frame_equal(expected, actual)

if __name__ == "__main__":
    unittest.main()