nessesary libraries and modules

-numpy
-pandas
-scipy.stats
-unittest
-unittest_data_provider
-matplotlib
-sklearn